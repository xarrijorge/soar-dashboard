import useMainStore from '../../store/mainStore'

export default function Preferences() {
  const { user, toggleTheme, toggleNotifications } = useMainStore()

  return (
    <div className="bg-white p-6 rounded-2xl shadow-md space-y-6 max-w-xl">
      <div className="flex items-center justify-between">
        <span className="text-[#2E3360] font-medium">Enable Notifications</span>
        <input
          type="checkbox"
          checked={user.notificationsEnabled}
          onChange={toggleNotifications}
          className="accent-[#2E3360] w-5 h-5"
        />
      </div>

      <div className="flex items-center justify-between">
        <span className="text-[#2E3360] font-medium">Dark Mode</span>
        <input
          type="checkbox"
          checked={user.theme === 'dark'}
          onChange={toggleTheme}
          className="accent-[#2E3360] w-5 h-5"
        />
      </div>
    </div>
  )
}